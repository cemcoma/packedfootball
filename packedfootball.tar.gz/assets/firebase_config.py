#Firebase project identifiers.

FIREBASE_API_KEY = "AIzaSyDi28SreBvnuodCs_hBuuQ6FiSMqno970g"
FIREBASE_PROJECT_ID = "packedfootball"
BACKEND_URL = "https://packedfootball-backend-485890967406.europe-west3.run.app"
