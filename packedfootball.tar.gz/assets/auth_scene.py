"""The sign-in / registration screen: the one place in the game that turns
raw keyboard input into an authenticated Firebase session.

Kept separate from main.py on purpose -- it's a self-contained unit (a text
input widget, a login/register form, and the Firebase calls that back it)
that main.py's state machine just delegates to for one scene, the same way
it already delegates match physics to gameEngine.py and pack rolls to
packEngine.py.

Why real accounts, not just a rename box: anonymous sign-in ties an account
to one browser/device via a locally-cached token. That's fine solo, but
falls over the moment friends want to open their own squad from a different
computer. Email/password accounts don't have that problem -- sign in with
the same email anywhere. "Continue as Guest" is kept as a fast path for
solo/local testing; it's still just anonymous auth under the hood.
"""

from __future__ import annotations

import pygame

from firebase_client import FirebaseClient, FirebaseError

FIELD_BG = (25, 25, 35)
FIELD_BORDER_ACTIVE = (80, 200, 80)
FIELD_BORDER_IDLE = (120, 120, 130)
TEXT_COLOR = (230, 230, 230)
PLACEHOLDER_COLOR = (110, 110, 120)
ERROR_COLOR = (230, 90, 90)


def friendly_auth_error(exc: FirebaseError) -> str:
    """Turns an Identity Toolkit error code into something a player can read."""
    code = exc.identity_error_code or ""
    if code.startswith("WEAK_PASSWORD"):
        return "Password must be at least 6 characters."
    known = {
        "EMAIL_EXISTS": "That email is already registered. Try signing in instead.",
        "EMAIL_NOT_FOUND": "No account found for that email. Try registering instead.",
        "INVALID_PASSWORD": "Incorrect password.",
        "INVALID_LOGIN_CREDENTIALS": "Incorrect email or password.",
        "INVALID_EMAIL": "That doesn't look like a valid email address.",
        "USER_DISABLED": "This account has been disabled.",
        "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many attempts. Try again in a bit.",
        "OPERATION_NOT_ALLOWED": "Email/password sign-in isn't enabled for this project yet.",
    }
    return known.get(code, f"Sign-in failed ({code or 'unknown error'}).")


class TextInput:
    """A minimal single-line text field driven by pygame's TEXTINPUT events.

    Call handle_event() with every pygame event each frame (it ignores ones
    it doesn't care about), then draw() to render it. Click to focus.
    """

    def __init__(self, rect, placeholder: str = "", is_password: bool = False, max_length: int = 96):
        self.rect = pygame.Rect(rect)
        self.text = ""
        self.placeholder = placeholder
        self.is_password = is_password
        self.max_length = max_length
        self.active = False

    def handle_event(self, event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.active = self.rect.collidepoint(event.pos)
        elif event.type == pygame.TEXTINPUT and self.active:
            if len(self.text) < self.max_length:
                self.text += event.text
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]

    def draw(self, screen, font) -> None:
        border = FIELD_BORDER_ACTIVE if self.active else FIELD_BORDER_IDLE
        pygame.draw.rect(screen, FIELD_BG, self.rect, border_radius=6)
        pygame.draw.rect(screen, border, self.rect, 2, border_radius=6)

        shown = ("•" * len(self.text)) if self.is_password else self.text
        if shown:
            surf = font.render(shown, True, TEXT_COLOR)
        else:
            surf = font.render(self.placeholder, True, PLACEHOLDER_COLOR)
        screen.blit(surf, (self.rect.x + 10, self.rect.y + (self.rect.height - surf.get_height()) // 2))


class AuthScene:
    """Renders the sign-in/register form and drives the Firebase calls behind it.

    Usage from main.py's per-frame loop:

        result = await auth_scene.update(screen, events, mouse_pos, mouse_clicked,
                                          font_large, font_btn, font_small, draw_button)
        if result is not None:
            # signed in this frame -- result["display_name"] is the name the
            # player chose at registration, or None for login/guest (in which
            # case the caller should fall back to whatever's already saved).
            ...
    """

    def __init__(self, client: FirebaseClient):
        self.client = client
        self.mode = "login"  # or "register"
        self.email = TextInput((490, 260, 300, 44), placeholder="email")
        self.password = TextInput((490, 320, 300, 44), placeholder="password", is_password=True)
        self.name = TextInput((490, 380, 300, 44), placeholder="display name")
        self.error = ""
        self.busy = False

    async def update(self, screen, events, mouse_pos, mouse_clicked, font_large, font_btn, font_small, draw_button):
        window_w = screen.get_width()

        title = font_large.render("PACKED FOOTBALL", True, (255, 255, 255))
        screen.blit(title, title.get_rect(center=(window_w / 2, 120)))
        subtitle = font_small.render("Sign in to save your squad and play PvP", True, (200, 200, 200))
        screen.blit(subtitle, subtitle.get_rect(center=(window_w / 2, 160)))

        for event in events:
            self.email.handle_event(event)
            self.password.handle_event(event)
            if self.mode == "register":
                self.name.handle_event(event)

        self.email.draw(screen, font_btn)
        self.password.draw(screen, font_btn)
        if self.mode == "register":
            self.name.draw(screen, font_btn)

        toggle_label = "New here? Register instead" if self.mode == "login" else "Already have an account? Sign in"
        if draw_button(screen, toggle_label, 490, 440, 300, 40, mouse_pos, mouse_clicked, font_small):
            self.mode = "register" if self.mode == "login" else "login"
            self.error = ""

        submit_label = "Register" if self.mode == "register" else "Sign In"
        submit_clicked = draw_button(screen, submit_label, 490, 500, 300, 55, mouse_pos, mouse_clicked, font_btn)

        if self.busy:
            busy_surf = font_small.render("Working...", True, (200, 200, 200))
            screen.blit(busy_surf, busy_surf.get_rect(center=(window_w / 2, 640)))
        elif self.error:
            err_surf = font_small.render(self.error, True, ERROR_COLOR)
            screen.blit(err_surf, err_surf.get_rect(center=(window_w / 2, 640)))

        if self.busy:
            return None
        
        if submit_clicked:
            email = self.email.text.strip()
            password = self.password.text
            if not email or not password:
                self.error = "Enter an email and password."
                return None

            self.busy = True
            try:
                if self.mode == "register":
                    display_name = self.name.text.strip() or email.split("@")[0]
                    await self.client.register_with_email(email, password)
                    return {"display_name": display_name}
                else:
                    await self.client.sign_in_with_email(email, password)
                    return {"display_name": None}
            except FirebaseError as exc:
                self.error = friendly_auth_error(exc)
                return None
            finally:
                self.busy = False

        return None
