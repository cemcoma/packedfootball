"""The sign-in / registration screen: the one place in the game that turns
raw keyboard input into an authenticated Firebase session.
"""

from __future__ import annotations

import itertools
import sys

import pygame

from firebase_client import FirebaseClient, FirebaseError

FIELD_BG = (25, 25, 35)
FIELD_BORDER_ACTIVE = (80, 200, 80)
FIELD_BORDER_IDLE = (120, 120, 130)
TEXT_COLOR = (230, 230, 230)
PLACEHOLDER_COLOR = (110, 110, 120)
ERROR_COLOR = (230, 90, 90)

_IS_EMSCRIPTEN = sys.platform == "emscripten"

# Must match main.py's WINDOW_SIZE -- every hardcoded UI rect in this app
# assumes this logical pygame resolution, regardless of the canvas's actual
# on-screen CSS size. Used below to scale a pygame rect into real page
# pixels when positioning a native overlay input.
_CANVAS_LOGICAL_SIZE = (1280, 800)

_dom_id_counter = itertools.count()

# Creates (once per id) and repositions a real HTML <input> on top of the
# canvas, matching a given pygame-space rect. Why this exists instead of
# window.prompt() (tried first) or a script-triggered .focus(): iOS Safari
# only shows the on-screen keyboard for a dialog or a focus() call that
# happens synchronously inside a genuine touch event. By the time pygame's
# event queue delivers a tap to Python, that window has already closed, so
# both of those approaches get silently blocked. A real, already-visible
# <input> that the user's finger lands on directly sidesteps the problem
# entirely: the tap itself is a native, trusted interaction with a real DOM
# element, handled by the browser with no script involved.
_OVERLAY_INPUT_JS = r"""
window.PFText = window.PFText || {};
window.PFText.ensure = function (id, x, y, w, h, placeholder, isPassword, value, logicalW, logicalH) {
    var el = document.getElementById(id);
    if (!el) {
        el = document.createElement('input');
        el.id = id;
        el.autocomplete = 'off';
        el.autocapitalize = 'off';
        el.autocorrect = 'off';
        el.spellcheck = false;
        el.style.position = 'fixed';
        el.style.zIndex = 999999;
        el.style.background = 'rgba(0,0,0,0)';
        el.style.color = '#e6e6e6';
        el.style.border = 'none';
        el.style.outline = 'none';
        el.style.padding = '0 8px';
        el.style.boxSizing = 'border-box';
        document.body.appendChild(el);
    }
    var canvas = document.getElementById('canvas');
    var rect = canvas.getBoundingClientRect();
    var scaleX = rect.width / logicalW;
    var scaleY = rect.height / logicalH;
    el.style.left = (rect.left + x * scaleX) + 'px';
    el.style.top = (rect.top + y * scaleY) + 'px';
    el.style.width = (w * scaleX) + 'px';
    el.style.height = (h * scaleY) + 'px';
    el.style.fontSize = Math.max(14, 20 * scaleY) + 'px';
    el.style.display = 'block';
    el.type = isPassword ? 'password' : 'text';
    el.placeholder = placeholder;
    // Only push our value in while the user ISN'T actively typing in it --
    // otherwise we'd fight the browser's own native editing every frame.
    if (document.activeElement !== el) {
        el.value = value;
    }
    return el.value;
};
window.PFText.hide = function (id) {
    var el = document.getElementById(id);
    if (el) el.style.display = 'none';
};
"""


def friendly_auth_error(exc: FirebaseError) -> str:
    """Turns an Identity Toolkit error code into something a player can read."""
    code = exc.identity_error_code or ""
    if code.startswith("WEAK_PASSWORD"):
        return "Password must be at least 6 characters."
    known = {
        "EMAIL_EXISTS": "That email is already registered. Try signing in instead.",
        "EMAIL_NOT_FOUND": "No account found for that email. Try registering instead.",
        "INVALID_PASSWORD": "Incorrect password.",
        "INVALID_LOGIN_CREDENTIALS": "Incorrect email or password.",
        "INVALID_EMAIL": "That doesn't look like a valid email address.",
        "USER_DISABLED": "This account has been disabled.",
        "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many attempts. Try again in a bit.",
        "OPERATION_NOT_ALLOWED": "Email/password sign-in isn't enabled for this project yet.",
    }
    return known.get(code, f"Sign-in failed ({code or 'unknown error'}).")


class TextInput:
    """A single-line text field.

    Desktop: driven by pygame TEXTINPUT events, drawn entirely on the canvas.

    Browser (emscripten): the box is still drawn on the canvas for a
    consistent look, but actual typing is handled by a real HTML <input>
    positioned exactly on top of it with a transparent background -- see
    _OVERLAY_INPUT_JS above for why that's necessary, not just a stylistic
    choice. handle_event()'s pygame-level click/type logic is effectively
    inert here, since the overlay sits above the canvas and intercepts the
    tap before pygame ever sees it; draw() -> _sync_native() is what keeps
    self.text current on this path instead.

    Call handle_event() with every pygame event each frame, draw() once per
    frame while the field is visible, and hide() the moment it stops being
    drawn (leaving its scene, or a mode toggle hiding it) -- otherwise the
    real overlay <input> is left sitting on top of whatever renders next,
    silently swallowing taps meant for it.
    """

    def __init__(self, rect, placeholder: str = "", is_password: bool = False, max_length: int = 96):
        self.rect = pygame.Rect(rect)
        self.text = ""
        self.placeholder = placeholder
        self.is_password = is_password
        self.max_length = max_length
        self.active = False
        self._dom_id = f"pftext_{next(_dom_id_counter)}"
        self._js_ready = False

    def handle_event(self, event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.active = self.rect.collidepoint(event.pos)
        elif event.type == pygame.TEXTINPUT and self.active:
            if len(self.text) < self.max_length:
                self.text += event.text
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]

    def draw(self, screen, font) -> None:
        if _IS_EMSCRIPTEN:
            self._sync_native()

        border = FIELD_BORDER_ACTIVE if self.active else FIELD_BORDER_IDLE
        pygame.draw.rect(screen, FIELD_BG, self.rect, border_radius=6)
        pygame.draw.rect(screen, border, self.rect, 2, border_radius=6)

        if not _IS_EMSCRIPTEN:
            # On the browser build the real overlay <input> renders its own
            # text and cursor natively; drawing our own here would double it.
            shown = ("•" * len(self.text)) if self.is_password else self.text
            if shown:
                surf = font.render(shown, True, TEXT_COLOR)
            else:
                surf = font.render(self.placeholder, True, PLACEHOLDER_COLOR)
            screen.blit(surf, (self.rect.x + 10, self.rect.y + (self.rect.height - surf.get_height()) // 2))

    def _sync_native(self) -> None:
        import platform  # pygbag's browser-interop shim, not stdlib platform

        if not self._js_ready:
            try:
                platform.window.eval(_OVERLAY_INPUT_JS)
            except AttributeError:
                return  # not actually running under pygbag's browser shim
            self._js_ready = True

        logical_w, logical_h = _CANVAS_LOGICAL_SIZE
        value = platform.window.PFText.ensure(
            self._dom_id, self.rect.x, self.rect.y, self.rect.w, self.rect.h,
            self.placeholder, self.is_password, self.text, logical_w, logical_h,
        )
        self.text = str(value)[: self.max_length]

    def hide(self) -> None:
        """Hides this field's native overlay input, if it was ever created."""
        if not _IS_EMSCRIPTEN or not self._js_ready:
            return
        import platform

        try:
            platform.window.PFText.hide(self._dom_id)
        except AttributeError:
            pass


class AuthScene:
    """Renders the sign-in/register form and drives the Firebase calls behind it.

    Usage from main.py's per-frame loop:

        result = await auth_scene.update(screen, events, mouse_pos, mouse_clicked,
                                          font_large, font_btn, font_small, draw_button)
        if result is not None:
            # signed in this frame -- result["display_name"] is the name the
            # player chose at registration, or None for login/guest (in which
            # case the caller should fall back to whatever's already saved).
            ...
    """

    def __init__(self, client: FirebaseClient):
        self.client = client
        self.mode = "login"  # or "register"
        self.email = TextInput((490, 260, 300, 44), placeholder="email")
        self.password = TextInput((490, 320, 300, 44), placeholder="password", is_password=True)
        self.name = TextInput((490, 380, 300, 44), placeholder="display name")
        self.error = ""
        self.busy = False

    def hide_native_inputs(self) -> None:
        """Hides every field's overlay input. Call before leaving this scene."""
        self.email.hide()
        self.password.hide()
        self.name.hide()

    async def update(self, screen, events, mouse_pos, mouse_clicked, font_large, font_btn, font_small, draw_button):
        window_w = screen.get_width()

        title = font_large.render("PACKED FOOTBALL", True, (255, 255, 255))
        screen.blit(title, title.get_rect(center=(window_w / 2, 120)))
        subtitle = font_small.render("Sign in to save your squad and play PvP", True, (200, 200, 200))
        screen.blit(subtitle, subtitle.get_rect(center=(window_w / 2, 160)))

        for event in events:
            self.email.handle_event(event)
            self.password.handle_event(event)
            if self.mode == "register":
                self.name.handle_event(event)

        self.email.draw(screen, font_btn)
        self.password.draw(screen, font_btn)
        if self.mode == "register":
            self.name.draw(screen, font_btn)

        toggle_label = "New here? Register instead" if self.mode == "login" else "Already have an account? Sign in"
        if draw_button(screen, toggle_label, 490, 440, 300, 40, mouse_pos, mouse_clicked, font_small):
            if self.mode == "login":
                self.mode = "register"
            else:
                self.name.hide()  # stops being drawn from here, so stop overlaying it too
                self.mode = "login"
            self.error = ""

        submit_label = "Register" if self.mode == "register" else "Sign In"
        submit_clicked = draw_button(screen, submit_label, 490, 500, 300, 55, mouse_pos, mouse_clicked, font_btn)

        if self.busy:
            busy_surf = font_small.render("Working...", True, (200, 200, 200))
            screen.blit(busy_surf, busy_surf.get_rect(center=(window_w / 2, 640)))
        elif self.error:
            err_surf = font_small.render(self.error, True, ERROR_COLOR)
            screen.blit(err_surf, err_surf.get_rect(center=(window_w / 2, 640)))

        if self.busy:
            return None

        if submit_clicked:
            email = self.email.text.strip()
            password = self.password.text
            if not email or not password:
                self.error = "Enter an email and password."
                return None

            self.busy = True
            try:
                if self.mode == "register":
                    display_name = self.name.text.strip() or email.split("@")[0]
                    await self.client.register_with_email(email, password)
                    self.hide_native_inputs()
                    return {"display_name": display_name}
                else:
                    await self.client.sign_in_with_email(email, password)
                    self.hide_native_inputs()
                    return {"display_name": None}
            except FirebaseError as exc:
                self.error = friendly_auth_error(exc)
                return None
            finally:
                self.busy = False

        return None
